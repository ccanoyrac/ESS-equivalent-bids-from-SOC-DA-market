# Research roadmap

## Core mechanism

The ISO owns the within-horizon intertemporal optimization. The storage owner does **not** need an interval-by-interval price forecast. Its private intertemporal valuation enters through the terminal value function

`b(s_T - sbar_T)`

where `sbar_T` is the terminal SOC implied by no market participation (including self-discharge).

The research frontier is therefore not merely "better battery physics". It is the interaction among:

- terminal valuation,
- uncertainty,
- market clearing and pricing,
- strategic incentives,
- DA/RT settlement,
- physical feasibility.

## Candidate thesis tracks

### Track A — Data-driven / stochastic terminal value (recommended)

Question: How should the ESS construct the end-of-horizon bid under uncertainty, and how sensitive is market efficiency to errors in this function?

Methods: stochastic dynamic programming, scenario optimization, approximate value functions, supervised learning, distributionally robust optimization.

### Track B — Strategic terminal bidding and market power

Question: Does replacing many interval bids with one terminal value function reduce or merely relocate market power?

Methods: bilevel optimization, KKT reformulation, equilibrium analysis, multiple storage owners, network congestion.

### Track C — DA/RT coupling under forecast error

Question: Can the terminal-SOC mechanism remain incentive-compatible and efficient in a rolling two-settlement market when renewable/load forecasts are wrong?

Methods: rolling horizon simulation, stochastic look-ahead, DA financial positions, RT deviations, lost-opportunity cost and settlement analysis.

### Track D — Price formation and dual degeneracy

Question: Which pricing rule should be used when intertemporal storage constraints create multiple valid LMP vectors, and how does the choice affect ESS surplus and incentives?

Methods: dual analysis, convex pricing, multi-period pricing, perturbation/tie-breaking rules, opportunity-cost pricing.

### Track E — Energy + ancillary-service co-optimization

Question: How should SOC feasibility and terminal value interact with reserve/regulation/inertia procurement?

High impact, but check contemporaneous work carefully because Baldick explicitly states that a future paper will address ancillary services.

## Suggested MSc scope

A strong, manageable thesis is **Track A + a limited DA/RT robustness test**. Avoid trying to solve terminal learning, strategic equilibrium, ancillary services, nonlinear degradation, and a large network in one thesis.
