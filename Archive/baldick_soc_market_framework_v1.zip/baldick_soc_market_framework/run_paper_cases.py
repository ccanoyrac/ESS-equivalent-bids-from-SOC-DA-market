from soc_market import base_case, high_wtp_case, increased_soc_case, solve_case

CASES = {
    "Table 2 - base": base_case,
    "Table 3 - high WTP": high_wtp_case,
    "Table 4 - increased SOC": increased_soc_case,
}

for name, factory in CASES.items():
    result = solve_case(factory())
    print("\n" + "=" * 80)
    print(name)
    print("=" * 80)
    print(result.table().round(3).to_string())
    print(f"Objective: {result.objective_value:,.3f}")
