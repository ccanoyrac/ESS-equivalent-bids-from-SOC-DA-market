# Baldick (2026) SOC-based storage market — reproducible starter framework

This repository is a clean-room implementation of the core convex model in:

Ross Baldick, *A state-of-charge based formulation for storage participation in electricity markets: Technical Reference*, arXiv:2606.14993 (2026).

It is intended as a thesis research scaffold: first reproduce the paper, then add new market-design or uncertainty modules without rewriting the core model.

## What is reproduced

The code implements the paper's equations (1)–(9) for the linear terminal bid used in the numerical examples and reproduces the **dispatch/SOC schedules** in Tables 2–4 (up to the paper's displayed rounding).

The paper solves its examples as LPs and relaxes charge/discharge mutual exclusivity. This implementation does the same. In the reported cases, simultaneous charging and discharging does not occur at optimum.

## Important pricing note

The primal schedules are reproducible, but some LMPs are **not unique** because the LP is degenerate. The paper itself gives intervals of valid clearing prices for some periods and then selects particular values (for example, $0/MWh or $41/MWh). A generic LP solver is allowed to return another valid dual solution in those intervals. Therefore, tests verify the physical/economic dispatch, not exact solver duals.

This is not a bug. In fact, price non-uniqueness is a potentially interesting research topic for this market design.

## Run

```bash
python -m pip install -r requirements.txt
python run_paper_cases.py
pytest -q
```

## Project structure

- `soc_market/data.py`: market/storage parameters.
- `soc_market/paper_cases.py`: Tables 2–4 cases.
- `soc_market/model.py`: LP market-clearing formulation and dual extraction.
- `run_paper_cases.py`: simple reproduction script.
- `tests/`: regression tests so future changes do not silently break the baseline.

## Recommended extension architecture

Do not modify the baseline equations every time you test an idea. Add new modules around them:

1. `terminal_value/`
   - piecewise-linear `b(ΔSOC)`
   - stochastic dynamic programming
   - learned value-to-go / quantile / robust terminal bids
2. `markets/`
   - day-ahead
   - rolling real-time
   - two-settlement DA/RT coupling
   - ancillary-service co-optimization
3. `participants/`
   - price-taker storage
   - strategic/price-maker storage
   - truthful vs distorted terminal bid
4. `network/`
   - single-node baseline
   - DC-OPF / nodal system
5. `physics/`
   - SOC-dependent power limits
   - nonlinear/piecewise efficiency
   - degradation / state-of-health
6. `experiments/`
   - Monte Carlo scenarios
   - welfare, profit, curtailment, prices, reliability
   - solver time and scaling

## First research experiment to add

Replace the constant terminal willingness-to-pay with a concave piecewise-linear value function `b(ΔSOC)`, generate the true value-to-go from scenarios beyond the market horizon, and compare:

- perfect terminal value,
- noisy/biased terminal value,
- learned terminal value,
- conventional interval-by-interval bids.

Measure system cost, renewable curtailment, storage profit, terminal SOC error, price volatility and regret. This directly tests the mechanism that is novel in Baldick's design.
