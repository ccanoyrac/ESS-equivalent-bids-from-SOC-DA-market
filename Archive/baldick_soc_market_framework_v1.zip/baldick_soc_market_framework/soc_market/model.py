from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from .data import CaseData


@dataclass
class MarketResult:
    objective_value: float
    renewable_mw: np.ndarray
    thermal_mw: np.ndarray
    charge_mw: np.ndarray
    discharge_mw: np.ndarray
    soc_mwh: np.ndarray
    lmp_per_mwh: np.ndarray
    raw_solver_result: object

    def table(self) -> pd.DataFrame:
        T = len(self.renewable_mw)
        return pd.DataFrame(
            {
                "Renewable MW": self.renewable_mw,
                "Thermal MW": self.thermal_mw,
                "ESS discharge MW": self.discharge_mw,
                "ESS charge MW": self.charge_mw,
                "ESS SOC MWh": self.soc_mwh,
                "Solver LMP $/MWh": self.lmp_per_mwh,
            },
            index=np.arange(1, T + 1),
        ).rename_axis("interval")


def solve_case(case: CaseData) -> MarketResult:
    """Solve the convex LP version of Baldick's equations (1)-(9).

    Mutual exclusivity p_t ⟂ g_t is relaxed exactly as in the paper's examples.
    With positive degradation costs and round-trip losses, the reproduced paper
    cases satisfy mutual exclusivity automatically.

    The terminal bid is linear here: b(Δs_T) = w * Δs_T.
    This is the form used in the three numerical examples.
    """
    m, e = case.market, case.storage
    T, dt = m.T, m.delta_t_h
    n = 5 * T

    # Variable blocks: [renewable, thermal, charge, discharge, SOC]
    i_r = slice(0, T)
    i_th = slice(T, 2*T)
    i_p = slice(2*T, 3*T)
    i_g = slice(3*T, 4*T)
    i_s = slice(4*T, 5*T)

    c = np.zeros(n)
    c[i_r] = dt * m.renewable_cost_per_mwh
    c[i_th] = dt * m.thermal_cost_per_mwh
    c[i_p] = dt * e.degradation_charge_per_mwh
    c[i_g] = dt * e.degradation_discharge_per_mwh
    # -b(s_T - sbar_T). Constant +w*sbar_T can be omitted.
    c[4*T + (T-1)] -= case.terminal_wtp_per_mwh

    A_eq, b_eq = [], []

    # Energy balance: renewable + thermal + discharge - charge = demand.
    for t in range(T):
        row = np.zeros(n)
        row[t] = 1.0
        row[T+t] = 1.0
        row[2*T+t] = -1.0
        row[3*T+t] = 1.0
        A_eq.append(row)
        b_eq.append(m.demand_mw[t])

    # SOC evolution: s_t = dt*alpha*p_t - dt*beta*g_t + gamma*s_{t-1}.
    for t in range(T):
        row = np.zeros(n)
        row[4*T+t] = 1.0
        row[2*T+t] = -dt * e.alpha_charge
        row[3*T+t] = dt * e.beta_discharge
        if t == 0:
            rhs = e.gamma_self_discharge * e.soc_initial_mwh
        else:
            row[4*T+t-1] = -e.gamma_self_discharge
            rhs = 0.0
        A_eq.append(row)
        b_eq.append(rhs)

    A_ub, b_ub = [], []

    # Tight SOC upper bound (paper eq. 6): gamma*s_{t-1}+dt*alpha*p_t <= s_max.
    # Tight SOC lower bound (paper eq. 7): gamma*s_{t-1}-dt*beta*g_t >= s_min.
    for t in range(T):
        row = np.zeros(n)
        row[2*T+t] = dt * e.alpha_charge
        if t == 0:
            rhs = e.soc_max_mwh - e.gamma_self_discharge * e.soc_initial_mwh
        else:
            row[4*T+t-1] = e.gamma_self_discharge
            rhs = e.soc_max_mwh
        A_ub.append(row)
        b_ub.append(rhs)

        row = np.zeros(n)
        row[3*T+t] = dt * e.beta_discharge
        if t == 0:
            rhs = e.gamma_self_discharge * e.soc_initial_mwh - e.soc_min_mwh
        else:
            row[4*T+t-1] = -e.gamma_self_discharge
            rhs = -e.soc_min_mwh
        A_ub.append(row)
        b_ub.append(rhs)

    bounds = []
    bounds += [(0.0, float(m.renewable_available_mw[t])) for t in range(T)]
    bounds += [(0.0, m.thermal_max_mw) for _ in range(T)]
    bounds += [(0.0, e.charge_max_mw) for _ in range(T)]
    bounds += [(0.0, e.discharge_max_mw) for _ in range(T)]
    bounds += [(None, None) for _ in range(T)]

    res = linprog(
        c,
        A_ub=np.asarray(A_ub),
        b_ub=np.asarray(b_ub),
        A_eq=np.asarray(A_eq),
        b_eq=np.asarray(b_eq),
        bounds=bounds,
        method="highs",
    )
    if not res.success:
        raise RuntimeError(res.message)

    x = res.x.reshape(5, T)
    # Balance dual is in $/MW for a dt-hour interval; divide by dt for $/MWh.
    lmp = np.asarray(res.eqlin.marginals[:T]) / dt

    return MarketResult(
        objective_value=float(res.fun),
        renewable_mw=x[0],
        thermal_mw=x[1],
        charge_mw=x[2],
        discharge_mw=x[3],
        soc_mwh=x[4],
        lmp_per_mwh=lmp,
        raw_solver_result=res,
    )
