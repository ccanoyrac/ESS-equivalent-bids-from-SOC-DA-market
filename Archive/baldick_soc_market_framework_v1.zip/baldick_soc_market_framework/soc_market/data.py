from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class MarketData:
    demand_mw: np.ndarray
    renewable_available_mw: np.ndarray
    thermal_cost_per_mwh: float = 50.0
    thermal_max_mw: float = 100.0
    renewable_cost_per_mwh: float = 0.0
    delta_t_h: float = 4.0

    @property
    def T(self) -> int:
        return len(self.demand_mw)


@dataclass(frozen=True)
class StorageData:
    alpha_charge: float = 0.9
    beta_discharge: float = 1.0
    gamma_self_discharge: float = 1.0
    degradation_charge_per_mwh: float = 1.0
    degradation_discharge_per_mwh: float = 1.0
    soc_min_mwh: float = 0.0
    soc_max_mwh: float = 800.0
    soc_initial_mwh: float = 0.0
    charge_max_mw: float = 1e6
    discharge_max_mw: float = 1e6


@dataclass(frozen=True)
class CaseData:
    market: MarketData
    storage: StorageData
    terminal_wtp_per_mwh: float = 40.0

    @property
    def reference_terminal_soc_mwh(self) -> float:
        """SOC at horizon end if the storage does not participate."""
        return (
            self.storage.gamma_self_discharge ** self.market.T
            * self.storage.soc_initial_mwh
        )
