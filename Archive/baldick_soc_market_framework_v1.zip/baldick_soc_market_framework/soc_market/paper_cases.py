import numpy as np
from .data import MarketData, StorageData, CaseData


def _market() -> MarketData:
    return MarketData(
        demand_mw=np.array([100, 200, 300, 300, 200, 100], dtype=float),
        renewable_available_mw=np.array([200, 100, 500, 500, 25, 0], dtype=float),
        thermal_cost_per_mwh=50.0,
        thermal_max_mw=100.0,
        renewable_cost_per_mwh=0.0,
        delta_t_h=4.0,
    )


def _storage(soc_max_mwh: float) -> StorageData:
    # The paper's numerical examples do not state finite charge/discharge power
    # limits in the list of case parameters. Large bounds therefore reproduce
    # the reported schedules; SOC and system balance are the active limits.
    return StorageData(
        alpha_charge=0.9,
        beta_discharge=1.0,
        gamma_self_discharge=1.0,
        degradation_charge_per_mwh=1.0,
        degradation_discharge_per_mwh=1.0,
        soc_min_mwh=0.0,
        soc_max_mwh=soc_max_mwh,
        soc_initial_mwh=0.0,
        charge_max_mw=1e6,
        discharge_max_mw=1e6,
    )


def base_case() -> CaseData:
    return CaseData(_market(), _storage(800.0), terminal_wtp_per_mwh=40.0)


def high_wtp_case() -> CaseData:
    return CaseData(_market(), _storage(800.0), terminal_wtp_per_mwh=55.0)


def increased_soc_case() -> CaseData:
    return CaseData(_market(), _storage(1200.0), terminal_wtp_per_mwh=40.0)
