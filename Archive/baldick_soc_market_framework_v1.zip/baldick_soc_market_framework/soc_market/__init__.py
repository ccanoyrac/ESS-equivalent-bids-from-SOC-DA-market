"""SOC-based electricity market model inspired by Baldick (2026)."""
from .data import MarketData, StorageData, CaseData
from .model import solve_case, MarketResult
from .paper_cases import base_case, high_wtp_case, increased_soc_case

__all__ = [
    "MarketData", "StorageData", "CaseData", "MarketResult", "solve_case",
    "base_case", "high_wtp_case", "increased_soc_case",
]
