import numpy as np
from soc_market import base_case, high_wtp_case, increased_soc_case, solve_case


def assert_close(actual, expected):
    np.testing.assert_allclose(actual, np.asarray(expected, dtype=float), atol=1e-5)


def test_base_case_dispatch_table_2():
    r = solve_case(base_case())
    assert_close(r.renewable_mw, [200,100,500,322.222222,25,0])
    assert_close(r.thermal_mw, [0,10,0,0,75,0])
    assert_close(r.discharge_mw, [0,90,0,0,100,100])
    assert_close(r.charge_mw, [100,0,200,22.222222,0,0])
    assert_close(r.soc_mwh, [360,0,720,800,400,0])


def test_high_wtp_dispatch_table_3():
    r = solve_case(high_wtp_case())
    assert_close(r.renewable_mw, [200,100,500,322.222222,25,0])
    assert_close(r.thermal_mw, [0,10,0,0,100,100])
    assert_close(r.discharge_mw, [0,90,0,0,75,0])
    assert_close(r.charge_mw, [100,0,200,22.222222,0,0])
    assert_close(r.soc_mwh, [360,0,720,800,500,500])


def test_increased_soc_dispatch_table_4():
    r = solve_case(increased_soc_case())
    assert_close(r.renewable_mw, [200,100,500,433.333333,25,0])
    assert_close(r.thermal_mw, [0,10,0,0,0,0])
    assert_close(r.discharge_mw, [0,90,0,0,175,100])
    assert_close(r.charge_mw, [100,0,200,133.333333,0,0])
    assert_close(r.soc_mwh, [360,0,720,1200,500,100])
